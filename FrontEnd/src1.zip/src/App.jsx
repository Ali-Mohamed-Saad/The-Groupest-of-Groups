// components/Settings.jsx

import { useState } from "react";
import SettingsNavbar   from "./components/Settings/SettingsNavbar";
import AccountTab       from "./components/Settings/tabs/AccountTab";
import NotificationsTab from "./components/Settings/tabs/NotificationsTab";
import SecurityTab      from "./components/Settings/tabs/SecurityTab";
import AppearanceTab    from "./components/Settings/tabs/AppearanceTab";

// Note: replace this path with wherever your ProfileTab actually lives
// import ProfileTab from "./components/Settings/SettingPage/Profile/ProfileTab";

const TAB_COMPONENTS = {
    // profile:       <ProfileTab />,
    account:       <AccountTab />,
    notifications: <NotificationsTab />,
    security:      <SecurityTab />,
    appearance:    <AppearanceTab />,
};

export default function Settings() {
    const [activeTab, setActiveTab] = useState("account");

    return (
        <div className="settings-container d-flex flex-column h-100 w-100 overflow-hidden">
            <div className="settings-header">
                <h2 className="settings-title">Settings</h2>
                <div className="settings-subtitle">
                    Manage your account settings, notifications, security credentials, and appearances
                </div>
            </div>

            <div className="settings-content-wrapper flex-column">
                <SettingsNavbar activeTab={activeTab} onTabChange={setActiveTab} />

                <div className="settings-workspace">
                    {TAB_COMPONENTS[activeTab]}
                </div>
            </div>
        </div>
    );
}