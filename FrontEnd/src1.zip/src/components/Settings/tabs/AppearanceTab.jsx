// components/Settings/tabs/AppearanceTab.jsx

import { useState } from "react";
import { useTheme } from "../../../context/ThemeContext.jsx";
import SettingsToast from "../../shared/SettingsToast.jsx";

export default function AppearanceTab() {
    const { currentTheme, setCurrentTheme, themes } = useTheme();
    const [toast, setToast] = useState({ show: false, message: "", type: "" });

    const applyTheme = (themeId) => {
        setCurrentTheme(themeId);
        const name = themes.find((t) => t.id === themeId)?.name;
        setToast({ show: true, message: `Theme changed to ${name}!`, type: "success" });
        setTimeout(() => setToast({ show: false, message: "", type: "" }), 3000);
    };

    return (
        <div className="settings-card">
            <h3 className="settings-card-title">Theme & Customization</h3>
            <SettingsToast {...toast} />

            <p className="text-muted" style={{ fontSize: "0.85rem" }}>
                Customize the interface color scheme to match your workflow aesthetic. Select from the harmonious themes below.
            </p>

            <div className="theme-picker-grid">
                {themes.map((theme) => (
                    <div
                        key={theme.id}
                        className={`theme-card ${currentTheme === theme.id ? "active" : ""}`}
                        onClick={() => applyTheme(theme.id)}
                    >
                        <div className="theme-preview">
                            <div className="theme-preview-sidebar" style={{ backgroundColor: theme.sidebar }} />
                            <div
                                className="theme-preview-body"
                                style={{ backgroundColor: theme.body, borderRight: `4px solid ${theme.primary}` }}
                            />
                        </div>
                        <span className="theme-card-name">{theme.name}</span>
                    </div>
                ))}
            </div>
        </div>
    );
}